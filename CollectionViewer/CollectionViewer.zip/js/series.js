// Structure of array 
// series['MTGM_EDITION_CODE'] = new Array('EDITION_CODE','NB CARDS','YEAR');

var series = new Array();
// Base editions
series['AL'] = new Array('LEA','295','1993');		//Alpha
series['BE'] = new Array('LEB','302','1993');		//Beta
series['UN'] = new Array('2ED','302','1993');	 	//Unlimited
series['RV'] = new Array('3ED','306','1994');		//Revised
series['3B'] = new Array('3ED','306','1994');		//Revised
series['3W'] = new Array('3ED','306','1994');	 	//Revised
series['4E'] = new Array('4ED','378','1995');	 	//4th Edition
series['5E'] = new Array('5ED','449','1997');	 	//5th Edition
series['6E'] = new Array('6ED','350','1999');	 	//6th Edition
series['7E'] = new Array('7ED','350','2001');	 	//7th Edition
series['8E'] = new Array('8ED','357','2003');	 	//8th Edition
series['9E'] = new Array('9ED','359','2005'); 		//9th Edition
series['1E'] = new Array('10E','383','2007');	 	//10E Edition
series['M1'] = new Array('M10','249','2009');	 	//Magic 2010
series['M2'] = new Array('M11','249','2010');	 	//Magic 2011
series['M3'] = new Array('M12','249','2011'); 		//Magic 2012
series['M4'] = new Array('M13','249','2012'); 		//Magic 2013
series['M5'] = new Array('M14','249','2013'); 		//Magic 2014
series['M6'] = new Array('M15','269','2014'); 		//Magic 2015

// Extensions 	
series['AN'] = new Array('ARN','92','1993'); 		//Arabian Nights
series['AQ'] = new Array('ATQ','100','1994'); 		//Antiquities
series['LE'] = new Array('LEG','310','1994'); 		//Legends
series['DK'] = new Array('DRK','119','1994'); 		//The Dark
series['FE'] = new Array('FEM','187','1994'); 		//Fallen Empires
series['HM'] = new Array('HML','140','1995'); 		//Homelands

// Ice Age Block
series['IA'] = new Array('ICE','383','1995'); 		//Ice Age
series['AC'] = new Array('ALL','199','1996'); 		//Alliances
series['CS'] = new Array('CSP','155','2006'); 		//Coldsnap
// Mirage Block
series['MR'] = new Array('MIR','350','1996'); 		//Mirage
series['VS'] = new Array('VIS','167','1997'); 		//Visions
series['WL'] = new Array('WTH','167','1997'); 		//Weatherlight
// Tempest Block
series['TP'] = new Array('TMP','350','1997'); 		//Tempest
series['SH'] = new Array('STH','143','1998'); 		//Stronghold
series['EX'] = new Array('EXO','143','1998'); 		//Exodus
// Urza Block
series['US'] = new Array('USG','350','1998'); 		//Urza's Saga
series['UL'] = new Array('ULG','143','1999'); 		//Urza's Legacy
series['UD'] = new Array('UDS','143','1999'); 		//Urza's Destiny
// Masques Block
series['MM'] = new Array('MMQ','350','1999'); 		//Mercadian Masques
series['NE'] = new Array('NEM','143','2000'); 		//Nemesis
series['PY'] = new Array('PCY','143','2000'); 		//Prophecy
// Invasion Block
series['IV'] = new Array('INV','350','2000'); 		//Invasion
series['PS'] = new Array('PLS','143','2000'); 		//Planeshift
series['AP'] = new Array('APC','143','2000');	 	//Apocalypse
// Odyssey Block
series['OD'] = new Array('ODY','350','2001');	 	//Odyssey
series['TO'] = new Array('TOR','143','2002'); 		//Torment
series['JU'] = new Array('JUD','143','2002'); 		//Judgment
// Onslaught Block
series['ON'] = new Array('ONS','350','2002'); 		//Onslaught
series['LG'] = new Array('LGN','145','2003'); 		//Legions
series['SC'] = new Array('SCG','143','2003');	 	//Scourge
// Mirrodin Block
series['MD'] = new Array('MRD','306','2003');	 	//Mirrodin
series['DS'] = new Array('DST','165','2004'); 		//Darksteel
series['FD'] = new Array('5DN','165','2004'); 		//Fifth Dawn
// Kamigawa Block
series['CK'] = new Array('CHK','306','2004'); 		//Champions Of Kamigawa
series['BK'] = new Array('BOK','165','2005'); 		//Betrayers of Kamigawa
series['SK'] = new Array('SOK','165','2005'); 		//Saviors of Kamigawa
// Ravnica Block
series['RA'] = new Array('RAV','306','2005'); 		//Ravnica: City of Guilds
series['GP'] = new Array('GPT','165','2006'); 		//Guildpact
series['DI'] = new Array('DIS','180','2006'); 		//Dissension
// Time Spiral Block
series['TD'] = new Array('TSB','422','2006');	 	//Time Spiral
series['TS'] = new Array('TSP','422','2006');	 	//Time Spiral
series['PC'] = new Array('PLC','165','2007');	 	//Planar Chaos
series['FS'] = new Array('FUT','180','2007'); 		//Future Sight
// Lorwyn Block
series['LW'] = new Array('LRW','301','2007');	 	//Lorwyn
series['MT'] = new Array('MOR','150','2008');	 	//Morningtide
// Shadowmoor Block
series['SM'] = new Array('SHM','301','2008');	 	//Shadowmoor
series['ET'] = new Array('EVE','180','2008'); 		//Eventide
// Alara Block
series['SL'] = new Array('ALA','249','2008');	 	//Shards Of Alara
series['CF'] = new Array('CFX','145','2009'); 		//Conflux
series['AR'] = new Array('ARB','145','2009'); 		//Alara Reborn
// Zendikar Block
series['ZK'] = new Array('ZEN','249','2009');	 	//Zendikar
series['WW'] = new Array('WWK','145','2010'); 		//Worldwake
series['RI'] = new Array('ROE','248','2010'); 		//Rise of the Eldrazi
// Scars Of Mirrodin Block
series['SD'] = new Array('SOM','249','2010');	 	//Scars of Mirrodin
series['MB'] = new Array('MBS','155','2011'); 		//Mirrodin Besieged
series['NP'] = new Array('NPH','175','2011');		//New Phyrexia
// Innistrad Block
series['IN'] = new Array('ISD','264','2011'); 		//Innistrad
series['DA'] = new Array('DKA','158','2012'); 		//Dark Ascension
series['YR'] = new Array('AVR','244','2012'); 		//Avacyn Restored
// Return To Ravnica Block
series['RR'] = new Array('RTR','274','2012');	 	//Return To Ravnica
series['GC'] = new Array('GTC','249','2013'); 		//Gatecrash
series['DZ'] = new Array('DGM','156','2013'); 		//Dragon's Maze
// Theros Block
series['TH'] = new Array('THS','249','2013'); 		//Theros
series['BG'] = new Array('BNG','165','2014'); 		//Born Of The Gods
series['JN'] = new Array('JOU','165','2014');		//Journey To Nyx

// Compilations
series['CH'] = new Array('CHR','125','1995');	 	//Chronicles
series['BT'] = new Array('BTD','2x61','2000'); 		//Beatdown
series['DM'] = new Array('DKM','2x62','2001');	 	//Deckmasters
series['RE'] = new Array('RE','122','1995'); 		//Renaissance -- Images not found

// Duel Decks
series['D3'] = new Array('EVG','2x60','2007'); 		//Duel Decks - Elve...
series['D5'] = new Array('DD2','2x60','2008'); 		//Duel Decks - Jace...
series['D1'] = new Array('DDC','2x60','2009'); 		//Duel Decks Divine...
series['D4'] = new Array('DDD','2x60','2009'); 		//Duel Decks Garruk...
series['D6'] = new Array('DDE','2x60','2010'); 		//Duel Decks Phyrex...
series['D2'] = new Array('DDF','2x60','2010'); 		//Duel Decks Elspet...
series['D7'] = new Array('DDG','2x60','2011'); 		//Duel Decks Knight...
series['D8'] = new Array('DDH','2x60','2011'); 		//Duel Decks Ajani ...

// From The Vault
series['V1'] = new Array('DRB','15','2008');	 	//From The Vault : Dragons
series['V2'] = new Array('V09','15','2009');	 	//From The Vault : Exiled
series['V3'] = new Array('V10','15','2010');	 	//From The Vault : Relics
series['V4'] = new Array('V11','15','2011');	 	//From The Vault : Legendes

// Premium Decks
series['R2'] = new Array('H09','60','2009');	 	//Premium Deck Series Slivers
series['R1'] = new Array('PD2','60','2010');	 	//Premium Deck Series Fire & Lightning
series['R3'] = new Array('PD3','60','2011'); 		//Premium Deck Series Graveborn

// Non Standard Legal Sets
series['PH'] = new Array('HOP','4x60+40','2009'); 	//Planechase
series['CD'] = new Array('CMD','5x100','2011'); 	//Commander
series['C3'] = new Array('C13','5x100','2013'); 	//Commander 2013

// Introductory Sets
series['P1'] = new Array('POR','222','1997');	 	//Portal
series['P2'] = new Array('P02','165','1998'); 		//Portal Second Age	OK
series['P3'] = new Array('PTK','180','1999');	 	//Portal Three King...
series['S1'] = new Array('S99','173','1999');	 	//Starter 1999
series['S2'] = new Array('S00','57','2000');	 	//Starter 2000

// Non Legal For Tournament Sets
series['UG'] = new Array('UGL','88','1998'); 		//Unglued
series['UH'] = new Array('UNH','141','2004');	 	//Unhinged

// Others
series['CT'] = new Array('?','?','?'); 				//Coldsnap Theme De...
series['HP'] = new Array('?','?','?'); 				//Promotion...
series['PG'] = new Array('?','?','?'); 				//P�gase





