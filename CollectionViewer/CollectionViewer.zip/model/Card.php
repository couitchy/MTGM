<?php

class Card {
	public $EncNbr;
	public $Title;
	public $TitleFR;
	public $SubTypeVF;
	public $TexteFR;
	public $Rarity;
	public $Series;
	public $SeriesNM_MtG;
	public $SeriesNM_FR;
	public $Items;
	public $Cost;
	public $Color;
	public $Price;
	
	public function setColor() {
		$multicolor = false;
		$this->Color = null;
		if (strstr($this->Cost, 'W')) {
			$this->Color = "White";
		}
		if (strstr($this->Cost, 'U')) {
			if (!is_null($this->Color))
				$this->Color = "Multicolor";
			else
				$this->Color = "Blue";
		}
		if (strstr($this->Cost, 'G')) {
			if (!is_null($this->Color))
				$this->Color = "Multicolor";
			else
				$this->Color = "Green";
		}
		if (strstr($this->Cost, 'R')) {
			if (!is_null($this->Color))
				$this->Color = "Multicolor";
			else
				$this->Color = "Red";
		}
		if (strstr($this->Cost, 'B')) {
			if (!is_null($this->Color))
				$this->Color = "Multicolor";
			else
				$this->Color = "Black";
		}
		if (is_null($this->Color)) {
			$this->Color = "Colorless";
		}
	}
	
	

}